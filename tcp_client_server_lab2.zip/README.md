# Lab: Java TCP sockets (request/response) (Programmatismos Katanemimenon Systhmaton)

DIT UoP

## Folder structure

- `src/gr/uop/ds/lab4/` Java sources
- `tests/` simple test cases (inputs -> expected outputs)

## Compile

From the lab folder:

```bash
mkdir -p out
javac -d out src/gr/uop/ds/lab4/*.java
```

## Run the server

```bash
java -cp out gr.uop.ds.lab4.TcpServer 5555
```

If you get `BindException: Address already in use`, choose another port (e.g. 6000).

## Test with 2 terminals using nc

Terminal A:

```bash
nc localhost 5555
OK READY
TIME
OK <timestamp>
```

Terminal B:

```bash
nc localhost 5555
OK READY
ECHO hi there
OK hi there
QUIT
OK bye
```

## Test with the included TcpClient

```bash
java -cp out gr.uop.ds.lab4.TcpClient localhost 5555 TIME
java -cp out gr.uop.ds.lab4.TcpClient localhost 5555 "ECHO hi"
```

Notes:
- The protocol is single-line request/response.
- Responses are always `OK ...` or `ERR ...`.
