package gr.uop.ds.lab4;

import java.time.LocalDateTime;

/**
 * Command parsing and routing for the lab protocol.
 *
 * Commands (single line):
 *   - ECHO <text>
 *   - TIME
 *   - HELP
 *   - QUIT
 *   - UPPER <text>   (mini in-class extension)
 */
public final class Commands {
  private Commands() {
    // utility class
  }

  public static String handle(String rawLine) {
    String line = (rawLine == null) ? "" : rawLine.trim();
    if (line.isEmpty()) {
      return "ERR 400 empty-request";
    }

    // Split into: COMMAND + (rest-of-line as args)
    String[] parts = line.split("\\s+", 2);
    String cmd = parts[0].toUpperCase();
    String args = (parts.length == 2) ? parts[1] : "";

    switch (cmd) {
      case "ECHO":
        return handleEcho(args);
      case "TIME":
        return "OK " + LocalDateTime.now();
      case "HELP":
        return handleHelp();
      case "UPPER":
        return handleUpper(args);
      case "QUIT":
        return "OK bye";
      default:
        return "ERR 404 unknown-command";
    }
  }

  private static String handleEcho(String args) {
    if (args.isEmpty()) {
      return "ERR 422 bad-args";
    }
    return "OK " + args;
  }

  private static String handleUpper(String args) {
    if (args.isEmpty()) {
      return "ERR 422 bad-args";
    }
    return "OK " + args.toUpperCase();
  }

  private static String handleHelp() {
    // Single-line help (easy to parse).
    return "OK COMMANDS: ECHO <text> | TIME | HELP | QUIT | UPPER <text>";
  }

  public static boolean isQuit(String rawLine) {
    if (rawLine == null) {
      return false;
    }
    return rawLine.trim().equalsIgnoreCase("QUIT");
  }
}
